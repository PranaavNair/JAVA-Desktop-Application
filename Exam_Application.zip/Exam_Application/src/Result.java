import java.awt.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.TreeSet;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

class Result extends JFrame {
	
		HashMap hm;
		
		JLabel marks=new JLabel();
		
		Result(){
			
			hm=Quiz.hm;
			marks.setText("YOU SCORED "+Quiz.score+" MARKS");
			
			marks.setFont(new Font("Times New Roman",Font.BOLD,30));
			
			setLayout(new BorderLayout());
			String[] columnNames = {"Qno","Question","Submitted Answer","Correct Answer","status"};
			
			 int rows=hm.size();
	            
		     String[][] result=new String[rows][5];
		     
		     //Collection c=hm.values();
		       
		    ArrayList al=new ArrayList(hm.values());
		    
		    Collections.sort(al,new QuestionSort());
		   
		    JTable table = new JTable(result,columnNames);
		    
		    JTableHeader header=table.getTableHeader();
				    header.setBackground(Color.BLACK);
				    header.setForeground(Color.WHITE);
				   
		     for(int i=0;i<rows;i++)
		       {
		    	   Question s1=(Question)al.get(i);
		           
		    	        for(int j=0;j<5;j++)
		             {

		               if(j==0)
		            	   result[i][j]=s1.getQueNo()+"";
		               if(j==1)
		  					result[i][j]=s1.getQuestion();
		               if(j==2)
		                    result[i][j]=s1.getSubmitted();
		               if(j==3)
		            	   result[i][j]=s1.getAnswer();
		               if(j==4 && s1.getSubmitted().equals(s1.getAnswer())) {
		                	result[i][j]="Right Answer".toUpperCase();
		            	   	//setForeground(Color.GREEN);
		                }
		               if(j==4 && !(s1.getSubmitted().equals(s1.getAnswer()))){
		            	   result[i][j]="Wrong Answer".toUpperCase() ;
		            	  // table.setForeground(Color.RED);
		               }
		             }
		       }
		     
		     table.setDefaultRenderer(Object.class, new TableCellRenderer()
		     {
		         JLabel comp = new JLabel();
		         String val;

		         public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
		         {
		            
		             comp.setForeground(Color.BLACK); 

		             if (value != null)
		             {
		                 val = value.toString();
		                 comp.setText(val);

		                 if (val.equalsIgnoreCase("wrong answer"))
		                 {
		                     comp.setForeground(Color.RED);
		                 }
		                 else if(val.equalsIgnoreCase("right answer")) {
		                	 comp.setForeground(Color.GREEN.darker());
		                 }
		             }
		             return comp;
		         }
		     });
		     
		     table.disable();
		     
		     
		     /*for(int i=0;i<5;i++) {
		         String ans = (String) table.getValueAt(1, i);
		     
		        if(ans=="Wrong Answer") {
		    	   table.setForeground(Color.RED);
		         }
		     }*/
		     
		     
		     String name= table.getColumnName(4);
		     
		        TableColumn column = null;
		        for (int i = 0; i < 5; i++) {
		            column = table.getColumnModel().getColumn(i);
		            if(i==0)
		            {
		            	column.setPreferredWidth(5);
		            }
		            if(i==1)
		            {
		            	column.setPreferredWidth(200);
		            }
		            if(i==2)
		            {
		            	column.setPreferredWidth(50);
		            }
		            if(i==3)
		            {
		            	column.setPreferredWidth(50);
		            }
		            if(i==4)
		            {
		            	column.setPreferredWidth(50);
		            }

		        }    

		        
		       table.setRowHeight(table.getRowHeight() + 25);
		       
		        JScrollPane scrollPane = new JScrollPane(table);
		        
		          table.setFillsViewportHeight(true);
		          
		          
		          
		          add(scrollPane,BorderLayout.NORTH);
		          add(marks,BorderLayout.SOUTH);
		}
		
}

