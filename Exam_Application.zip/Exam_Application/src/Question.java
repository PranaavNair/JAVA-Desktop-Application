
public class Question {
	
	int queNo;
	String question,answer,submitted;
	
	
	public Question(int queNo, String question, String answer, String submitted) {
		super();
		this.queNo = queNo;
		this.question = question;
		this.answer = answer;
		this.submitted = submitted;
	}


	public int getQueNo() {
		return queNo;
	}


	public void setQueNo(int queNo) {
		this.queNo = queNo;
	}


	public String getQuestion() {
		return question;
	}


	public void setQuestion(String question) {
		this.question = question;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}


	public String getSubmitted() {
		return submitted;
	}


	public void setSubmitted(String submitted) {
		this.submitted = submitted;
	}
	
	

}
