import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Quiz extends JFrame implements ActionListener, ItemListener {
	
	static int score = 0;

	JButton button,next,previous,start;
	JLabel label1;
	JPanel intropanel, panel1, panel2, panel3, panel4, panel5, panel6, panel7, panel8, panel9, panel10, panel11, panel12, panel13, panel14, panel15, panel16, panel17, panel18, panel19, panel20;
	JRadioButton r1, r2, r3, r4;
	JTextArea text1;
	JTextField ansText;
	JTextArea introtext;

	JTabbedPane tab;
	static HashMap<String, Question> hm = new HashMap<String, Question>();

	public Quiz() {
		setLayout(new BorderLayout());

		tab = new JTabbedPane();
		button = new JButton("END EXAM");
		next = new JButton("NEXT");
		previous= new JButton("PREVIOUS");
		//start=new JButton("START EXAM");


		introtext = new JTextArea();
		intropanel = new JPanel();
		panel1 = new JPanel();
		panel2 = new JPanel();
		panel3 = new JPanel();
		panel4 = new JPanel();
		panel5 = new JPanel();
		panel6 = new JPanel();
		panel7 = new JPanel();
		panel8 = new JPanel();
		panel9 = new JPanel();
		panel10 = new JPanel();
		panel11 = new JPanel();
		panel12 = new JPanel();
		panel13 = new JPanel();
		panel14 = new JPanel();
		panel15 = new JPanel();
		panel16 = new JPanel();
		panel17 = new JPanel();
		panel18 = new JPanel();
		panel19 = new JPanel();
		panel20 = new JPanel();
		

		intropanel.setLayout(null);

		panel1.setLayout(null);
		panel2.setLayout(null);
		panel3.setLayout(null);
		panel4.setLayout(null);
		panel5.setLayout(null);
		panel6.setLayout(null);
		panel7.setLayout(null);
		panel8.setLayout(null);
		panel9.setLayout(null);
		panel10.setLayout(null);
		panel11.setLayout(null);
		panel12.setLayout(null);
		panel13.setLayout(null);
		panel14.setLayout(null);
		panel15.setLayout(null);
		panel16.setLayout(null);
		panel17.setLayout(null);
		panel18.setLayout(null);
		panel19.setLayout(null);
		panel20.setLayout(null);
		
		next.setLayout(null);
		
		next.setBackground(Color.CYAN);
		previous.setBackground(Color.CYAN);
		
		introtext = new JTextArea("RULES: \n\t1)20 questions \n\t2)1 mark each \n\t3)Time: 10 minutes");
		introtext.setFont(new Font("Times New Roman", Font.BOLD, 30));
		introtext.setBounds(50, 100, 1000, 200);
		intropanel.add(introtext);
		next.setBounds(1100,550,150,30);
		intropanel.add(next);
		/*start.setBounds(550,450,250,30);
		start.setFont(new Font("Times New Roman",Font.BOLD,30));
		intropanel.add(start);*/
		

		tab.add("Intro", intropanel);
		tab.add("1", panel1);
		tab.add("2", panel2);
		tab.add("3", panel3);
		tab.add("4", panel4);
		tab.add("5", panel5);
		tab.add("6", panel6);
		tab.add("7", panel7);
		tab.add("8", panel8);
		tab.add("9", panel9);
		tab.add("10", panel10);
		tab.add("11", panel11);
		tab.add("12", panel12);
		tab.add("13", panel13);
		tab.add("14", panel14);
		tab.add("15", panel15);
		tab.add("16", panel16);
		tab.add("17", panel17);
		tab.add("18", panel18);
		tab.add("19", panel19);
		tab.add("20", panel20);
		
		tab.disable();
	

		tab.addChangeListener(new ChangeListener() {

			public void stateChanged(ChangeEvent changeEvent) {
				add("South", button);
				next.setBounds(1100,550,150,30);
				previous.setBounds(200,550,150,30);
				
				//add(next.setBounds(50,350,150,30));
				//add(BorderLayout.BEFORE_LINE_BEGINS,next);			
				//next.setLocation(700, 700);
				//next.setVisible(true);
				
				ButtonGroup bg = new ButtonGroup();
				JTabbedPane sourceTabbedPane = (JTabbedPane) changeEvent.getSource();
				int index = sourceTabbedPane.getSelectedIndex();
				String tabname = sourceTabbedPane.getTitleAt(index);

				switch (tabname) {

				case "1":

					ansText = new JTextField("Object");
					// ansText.setVisible(false);

					label1 = new JLabel("Q1");
					label1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1 = new JTextArea("Super Class of every class is ________ .");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("String");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("Object");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("Java");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("lang");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					// ansText.setBounds(50,350,100,30);

					panel1.add(label1);
					panel1.add(text1);
					panel1.add(r1);
					panel1.add(r2);
					panel1.add(r3);
					panel1.add(r4);
					panel1.add(next);
					//panel1.add(previous);
					//panel1.add(ansText);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;

				case "2":

					ansText = new JTextField("public and abstract");
					
					label1 = new JLabel("Q2");
					label1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1 = new JTextArea("Interface methods are ________ .");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("private & non-abstract");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("private & abstract");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("public and abstract");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("public & non-abstract");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel2.add(label1);
					panel2.add(text1);
					panel2.add(r1);
					panel2.add(r2);
					panel2.add(r3);
					panel2.add(r4);
					panel2.add(next);
					panel2.add(previous);
					
					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
				case "3":

					ansText = new JTextField("interface");
					
					label1 = new JLabel("Q3");
					label1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1 = new JTextArea("Collection is a :- ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("interface");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("class");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("method");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("none of these");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel3.add(label1);
					panel3.add(text1);
					panel3.add(r1);
					panel3.add(r2);
					panel3.add(r3);
					panel3.add(r4);
					panel3.add(next);
					panel3.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;

				case "4":

					ansText = new JTextField("TreeSet");
					
					label1 = new JLabel("Q4");
					label1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1 = new JTextArea("Which of the following is a sorted collection :-  ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("ArrayList");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("HashSet");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("TreeSet");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("All of these");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel4.add(label1);
					panel4.add(text1);
					panel4.add(r1);
					panel4.add(r2);
					panel4.add(r3);
					panel4.add(r4);
					panel4.add(next);
					panel4.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
				case "5":

					ansText = new JTextField("ArrayList");
					
					label1 = new JLabel("Q5");
					label1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1 = new JTextArea("Which of the following is a ordered collection ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("ArrayList");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("HashSet");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("TreeSet");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("All of these");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel5.add(label1);
					panel5.add(text1);
					panel5.add(r1);
					panel5.add(r2);
					panel5.add(r3);
					panel5.add(r4);
					panel5.add(next);
					panel5.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
				case "6":

					ansText = new JTextField("HashMap");
					
					label1 = new JLabel("Q6");
					label1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1 = new JTextArea(" Which of the following is not a legacy class:-  ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("HashTable");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("HashMap");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("Properties");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("Vector");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel6.add(label1);
					panel6.add(text1);
					panel6.add(r1);
					panel6.add(r2);
					panel6.add(r3);
					panel6.add(r4);
					panel6.add(next);
					panel6.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
				case "7":

					ansText = new JTextField("interface");

					label1 = new JLabel("Q7");
					label1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1 = new JTextArea("Iterator is a :- ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("interface");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("method");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("class");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("None of these");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel7.add(label1);
					panel7.add(text1);
					panel7.add(r1);
					panel7.add(r2);
					panel7.add(r3);
					panel7.add(r4);
					panel7.add(next);
					panel7.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
				case "8":

					ansText = new JTextField("Throwable");
					
					label1 = new JLabel("Q8");
					label1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1 = new JTextArea("Which one is a superclass of all Exception type ?  ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("Exception");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("Error");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("Throwable");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("None of these");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel8.add(label1);
					panel8.add(text1);
					panel8.add(r1);
					panel8.add(r2);
					panel8.add(r3);
					panel8.add(r4);
					panel8.add(next);
					panel8.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
				
				case "9":

					ansText = new JTextField("final");
				
					label1 = new JLabel("Q9");
					label1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1 = new JTextArea("Which of the following variable value can't be changed ?  ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("static");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("final");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("instance");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("None of these");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel9.add(label1);
					panel9.add(text1);
					panel9.add(r1);
					panel9.add(r2);
					panel9.add(r3);
					panel9.add(r4);
					panel9.add(next);
					panel9.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
					
				case "10":

					ansText = new JTextField("it can be protected");
		
					label1 = new JLabel("Q10");
					label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
					text1 = new JTextArea("Which of the following is not true about local variable ? ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("its initialization is compulsory");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("it can be protected");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("its scope is limited to the block where we have initialized it");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("All of these");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel10.add(label1);
					panel10.add(text1);
					panel10.add(r1);
					panel10.add(r2);
					panel10.add(r3);
					panel10.add(r4);
					panel10.add(next);
					panel10.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
				
				case "11":

					ansText = new JTextField("non subclass from outside package");
				
					label1 = new JLabel("Q11");
					label1.setFont(new Font("Times New Roman",  Font.BOLD, 20));
					text1 = new JTextArea("protected member is not accessible in :-  ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("all class from same package");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("only sub class from outside package");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("non subclass from outside package");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("All of these");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel11.add(label1);
					panel11.add(text1);
					panel11.add(r1);
					panel11.add(r2);
					panel11.add(r3);
					panel11.add(r4);
					panel11.add(next);
					panel11.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
					
				case "12":

					ansText = new JTextField("it can have static method");
				
					label1 = new JLabel("Q12");
					label1.setFont(new Font("Times New Roman",  Font.BOLD, 20));
					text1 = new JTextArea("what is not true about interface ?  ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("it can have static method");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("it can only have abstract method");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("It can have constants");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("All of these");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel12.add(label1);
					panel12.add(text1);
					panel12.add(r1);
					panel12.add(r2);
					panel12.add(r3);
					panel12.add(r4);
					panel12.add(next);
					panel12.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
					
				case "13":

					ansText = new JTextField("String");
					
					label1 = new JLabel("Q13");
					label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
					text1 = new JTextArea("Which of the following is not a Mutable Object ?  ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("StringBuffer");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("System");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("StringBuilder");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("String");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel13.add(label1);
					panel13.add(text1);
					panel13.add(r1);
					panel13.add(r2);
					panel13.add(r3);
					panel13.add(r4);
					panel13.add(next);
					panel13.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
					
				case "14":

					ansText = new JTextField("NullPointerException");
					
					label1 = new JLabel("Q14");
					label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
					text1 = new JTextArea("Which of the following is not a checked exception ?");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("NullPointerException");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("IOException");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("SQLException");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("FileNotFoundException");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel14.add(label1);
					panel14.add(text1);
					panel14.add(r1);
					panel14.add(r2);
					panel14.add(r3);
					panel14.add(r4);
					panel14.add(next);
					panel14.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
					
				case "15":

					ansText = new JTextField("Collection");
					
					label1 = new JLabel("Q15");
					label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
					text1 = new JTextArea("Which of the following is not a marker interface ?");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("Serializable");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("Cloneable");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("Collection");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("All of these");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel15.add(label1);
					panel15.add(text1);
					panel15.add(r1);
					panel15.add(r2);
					panel15.add(r3);
					panel15.add(r4);
					panel15.add(next);
					panel15.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
					
				case "16":

					ansText = new JTextField("finally");
					
					label1 = new JLabel("Q16");
					label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
					text1 = new JTextArea("which of the following block always executes ? ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("try");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("catch");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("finally");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("None of the above");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel16.add(label1);
					panel16.add(text1);
					panel16.add(r1);
					panel16.add(r2);
					panel16.add(r3);
					panel16.add(r4);
					panel16.add(next);
					panel16.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
					
				case "17":

					ansText = new JTextField("instanceof");
					
					label1 = new JLabel("Q17");
					label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
					text1 = new JTextArea("which operator is used to test whether the object is instance of particular class/interface ?");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("instanceof");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("instanceOf");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("isObject");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("All of the above");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel17.add(label1);
					panel17.add(text1);
					panel17.add(r1);
					panel17.add(r2);
					panel17.add(r3);
					panel17.add(r4);
					panel17.add(next);
					panel17.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
					
				case "18":

					ansText = new JTextField("getBytes()");
					
					label1 = new JLabel("Q18");
					label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
					text1 = new JTextArea("which of the following is not method from Object Class ? ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("getBytes()");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("wait()");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("equals()");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("toString()");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel18.add(label1);
					panel18.add(text1);
					panel18.add(r1);
					panel18.add(r2);
					panel18.add(r3);
					panel18.add(r4);
					panel18.add(next);
					panel18.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
					
				case "19":

					ansText = new JTextField("Both of the above");
					
					label1 = new JLabel("Q19");
					label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
					text1 = new JTextArea("Which keyword we can't use in static context ? ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("this");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("super");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("Both of the above");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("None of the above");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel19.add(label1);
					panel19.add(text1);
					panel19.add(r1);
					panel19.add(r2);
					panel19.add(r3);
					panel19.add(r4);
					panel19.add(next);
					panel19.add(previous);
					

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
					
				case "20":

					ansText = new JTextField("It can access non-static members of outer class");
					
					label1 = new JLabel("Q20");
					label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
					text1 = new JTextArea("what is false about static nested class ? ");
					text1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					text1.setForeground(Color.white);
					text1.setBackground(Color.black);
					text1.setLineWrap(true);

					r1 = new JRadioButton("It can access non-static members of outer class");
					r1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r2 = new JRadioButton("It can access static members of outer class");
					r2.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r3 = new JRadioButton("we can write main() in it");
					r3.setFont(new Font("Times New Roman", Font.PLAIN, 30));
					r4 = new JRadioButton("None of the above");
					r4.setFont(new Font("Times New Roman", Font.PLAIN, 30));

					label1.setBounds(40, 50, 40, 40);
					text1.setBounds(100, 50, 1200, 50);
					r1.setBounds(50, 150, 650, 50);
					r2.setBounds(50, 200, 650, 50);
					r3.setBounds(50, 250, 650, 50);
					r4.setBounds(50, 300, 650, 50);

					panel20.add(label1);
					panel20.add(text1);
					panel20.add(r1);
					panel20.add(r2);
					panel20.add(r3);
					panel20.add(r4);
					panel20.add(previous);

					bg.add(r1);
					bg.add(r2);
					bg.add(r3);
					bg.add(r4);

					r1.addItemListener(Quiz.this);
					r2.addItemListener(Quiz.this);
					r3.addItemListener(Quiz.this);
					r4.addItemListener(Quiz.this);

					break;
				}
				
			
			}
		});

		add("Center", tab);

		setSize(Toolkit.getDefaultToolkit().getScreenSize());

		setVisible(true);

		button.addActionListener(this);
		next.addActionListener(new next());
		previous.addActionListener(new previous());
		
	}
	
	class next implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			int nexttab=tab.getSelectedIndex()+1;
			tab.setSelectedIndex(nexttab);
			
			
		}
		
		
	}
	
	class previous implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			int previoustab=tab.getSelectedIndex()-1;
			tab.setSelectedIndex(previoustab);
			
			
		}
		
		
	}

	public static void main(String[] args) {
		new Quiz();
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {

		

		Collection c = hm.values();

		Iterator it = c.iterator();

		while (it.hasNext()) {
			Question q = (Question) it.next();
			//System.out.println("Correct Answer" + "       " + "            Your Answer");

			//System.out.println(q.answer + "              " + q.submitted);
			if (q.answer.equals(q.submitted)) {
				score = score + 1;

			}

		}

		System.out.println("Score= " + score);
		
		this.setVisible(false);
		
		Result result=new Result();
		result.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		result.setVisible(true);
		

	}

	public void itemStateChanged(ItemEvent e) {

		JRadioButton selectedradio = (JRadioButton) e.getSource();
		
		if(selectedradio.hasFocus())
			selectedradio.setForeground(Color.MAGENTA);
		else
			selectedradio.setForeground(Color.BLACK);

		String qno1 = tab.getTitleAt(tab.getSelectedIndex());
		int qno = Integer.parseInt(tab.getTitleAt(tab.getSelectedIndex()));
		int key = qno;

		String submittedAnswer = selectedradio.getText();
		String questionText = text1.getText();
		String correctAnswer = ansText.getText();

		Question question = new Question(key, questionText, correctAnswer, submittedAnswer);

		hm.put(qno1, question);

		// System.out.println(hm);

	}
}
