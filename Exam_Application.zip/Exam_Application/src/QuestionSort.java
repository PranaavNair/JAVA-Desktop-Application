import java.util.Comparator;

public class QuestionSort implements Comparator{

	public int compare(Object obj1, Object obj2) {
		
		Question que1=(Question)obj1;
		Question que2=(Question)obj2;
		
		//int compare=que1.queNo.compareTo(que2.queNo);
		
		if(que1.queNo==que2.queNo)
			return 0;
		else if(que1.queNo>que2.queNo)
			return 1;
		else
			return -1;
		
		
	}
	

}
